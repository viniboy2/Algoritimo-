caderno de anotação da aula "ver a forma de printf e sacanf e ymb if else e if else"
em c# temos tipos finitos de variaveis e cada uma é utilizado para um motivo 
tipo de um numero inteiro é o tipo INT(vai do mais infinito até o menos infinito)


AULA DE HOJE sobre"gith">hub gratuito e outra parte paga > lab maior parte gratuita mas tem parte paga
"limk do gith hub para validar a atividade"

//vamos criar uma calculadora %d e para int %f e para float loong int 


